from flask import Flask, render_template, request, url_for, redirect
import pygal
import mysql.connector
import json
from mysql.connector import errorcode
from pygal.style import DarkSolarizedStyle
from pygal.style import Style
app = Flask(__name__)

@app.route('/')
def homepage():
   return render_template("index.html")

@app.route('/data')
def blog():
    db = mysql.connector.connect(user = 'sensored',
                                password = 'stevens2014',
                                host = 'sensored.cdrs74k0clf3.us-east-1.rds.amazonaws.com',
                                database = 'SensorEdAWS')

   #Assign the curser to manage the database
    cursor = db.cursor()
   #Retrieve Data
    cursor.execute('''SELECT dateNow, timeNow, temperature, pressure, humidity, gas FROM b827ebb798b6''')
    #Declare a variable that will acquire all the data using cursor.fethchall()
    all_rows = cursor.fetchall()
    temps = []
    pressure = []
    humidity = []
    gas = []
    times = []
    count = 0
    #GETDATA
    for row in all_rows[0:1439]:
           try: 
              temps.append(row[2])
              pressure.append(row[3])
              humidity.append(row[4])
              if row[5] < 50000:
                 gas.append(row[5])
              else:
                 gas.append(None)
              
           except: 
              temps.append(None)
              pressure.append(None)
              humidity.append(None)
              gas.append(None)
           tempDate = row[0]
           tempTime = row[1]
           tempCombo = str(tempDate)
           if count % 288 == 0:
                   times.append(tempCombo)
           else:
                   times.append(None)
           count += 1
           
    # create a bar chart
    custom_style = Style(
    background='transparent',
    plot_background='transparent',
    foreground='#fff',
    foreground_strong='#3fff00',
    foreground_subtle='#fff',
    opacity='.6',
    opacity_hover='.9',
    title_font_size = 30.0,
    transition='400ms ease-in',
    colors=('#3fff00', '#3fff00', '#3fff00', '#3fff00', '#3fff00'))
    titleTemp = 'Temperature in ADS Lab (Outside of Box)'
    titlePressure = 'Pressure in ADS Lab (Outside of Box)'
    titleHumidity = 'Humidity in ADS Lab (Outside of Box)'
    titleGas = 'Gas in ADS Lab (Outside of Box)'
    
    #Temp
    line_chart_temp = pygal.Line(width=1200, height=600,
                         explicit_size=True, title=titleTemp,
                         disable_xml_declaration=True, x_label_rotation=20, style=custom_style)
    line_chart_temp.x_labels = times
    line_chart_temp.add('Temp: F', temps)
    #Pressure
    line_chart_pressure = pygal.Line(width=1200, height=600,
                         explicit_size=True, title=titlePressure,
                         disable_xml_declaration=True, x_label_rotation=20, style=custom_style)
    line_chart_pressure.x_labels = times
    line_chart_pressure.add('Pressure: hPa', pressure)
    #Humidity
    line_chart_humidity = pygal.Line(width=1200, height=600,
                         explicit_size=True, title=titleHumidity,
                         disable_xml_declaration=True, x_label_rotation=20, style=custom_style)
    line_chart_humidity.x_labels = times
    line_chart_humidity.add('Humidity: %', humidity)
    #Gas
    line_chart_gas = pygal.Line(width=1200, height=600,
                         explicit_size=True, title=titleGas,
                         disable_xml_declaration=True, x_label_rotation=20, style=custom_style)
    line_chart_gas.x_labels = times
    line_chart_gas.add('Gas Resistence: Ohms', gas)

    #Return
    return render_template("data.html",
                          line_chart_temp=line_chart_temp,
                          line_chart_pressure=line_chart_pressure,
                          line_chart_humidity=line_chart_humidity,
                          line_chart_gas=line_chart_gas)


if __name__ == "__main__":
	app.run()
